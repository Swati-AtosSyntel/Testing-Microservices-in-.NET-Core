﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Threading.Tasks;

namespace CatalogService.Models
{
    public class DataBaseContext:DbContext
    {
        public DataBaseContext(DbContextOptions<DataBaseContext> options):base(options)
        {

        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category
                {
                    CategoryId = 1,
                    Name = "Electronics"

                },
                new Category
                {
                    CategoryId = 2,
                    Name = "Clothes"

                },
                new Category
                {
                    CategoryId = 3,
                    Name = "Grocery"

                }
            );
            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                   ProductID= 123,
                    ProductName = "Dell Laptop",
                    
                    CategoryId = 1

                },
                new Product
                {
                    ProductID = 124,
                    ProductName = "Jeans",
                    
                    CategoryId = 2
                }

            );
        }
    }
}
